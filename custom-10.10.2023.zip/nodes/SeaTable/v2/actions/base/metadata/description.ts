import type { BaseProperties } from '../../Interfaces';

export const baseMetadataDescription: BaseProperties = [];
