import { apiCall as execute } from './execute';
import { baseApiCallDescription as description } from './description';

export { description, execute };
