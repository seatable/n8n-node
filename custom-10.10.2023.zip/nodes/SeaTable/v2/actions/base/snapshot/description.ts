import type { BaseProperties } from '../../Interfaces';

export const baseSnapshotDescription: BaseProperties = [];
