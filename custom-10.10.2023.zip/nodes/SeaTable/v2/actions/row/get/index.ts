import { get as execute } from './execute';
import { rowGetDescription as description } from './description';

export { description, execute };
