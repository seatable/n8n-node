import { update as execute } from './execute';
import { rowUpdateDescription as description } from './description';

export { description, execute };
