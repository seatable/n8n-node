import { remove as execute } from './execute';
import { rowRemoveDescription as description } from './description';

export { description, execute };
