import { unlock as execute } from './execute';
import { rowUnlockDescription as description } from './description';

export { description, execute };
