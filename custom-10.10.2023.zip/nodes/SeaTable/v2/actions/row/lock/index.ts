import { lock as execute } from './execute';
import { rowLockDescription as description } from './description';

export { description, execute };
