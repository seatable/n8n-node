import { remove as execute } from './execute';
import { linkRemoveDescription as description } from './description';

export { description, execute };
